#include <algorithm>
#include <cmath>
	
#include "points.h"


pointset convexHullGrahamScan( pointset S )
{
	pointset CH(size, coord(0, 0));


	return CH;
}

pointset convexHullJarvisMarch( pointset S )
{
	pointset CH(size, coord(0, 0));


	return CH;
}

pointset convexHullAndrew( pointset S )
{
	pointset CH(size, coord(0, 0));


	return CH;
}
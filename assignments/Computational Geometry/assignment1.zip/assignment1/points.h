#include <vector>


//	Semantic alias for necessary Data Structues and functions.
#define point pair<float, float> 
#define pointset vector<point> 
#define coord make_pair 
#define addPoint push_back 

using namespace std;

//	Global variables
int size = 0;
int sizeCH = 0;
pointset S;
pointset CH;

double distBetween( point a, point b )
{
	double distance = 0;

	return distance;
}

double angleBetween( point a, point b )
{
	double angle = 0;

	return angle;
}

point getInteriorPoint( pointset S )
{
	point inside = coord(0, 0);

	return inside;
}

point getExteriorPoint( pointset S )
{
	point outside = coord(0, 0);

	return outside;
}

double signedArea( point a, point b, point c )
{
	double area = 0;

	return area;
}


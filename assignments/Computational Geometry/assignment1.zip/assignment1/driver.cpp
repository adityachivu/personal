#include <iostream>
#include <cstdio>
#include "algorithm.h"
using namespace std;

int main()
{
	cout << "Hello" << endl;

	cin >> size;
	for ( int i = 0; i < size; i++ )
	{
		int x, y;
		cin >> x >> y;
		S.addPoint( coord(x, y) );
	}

	CH = convexHullGrahamScan( S );
	cout << sizeCH << endl;
	for ( int i = 0; i < sizeCH; i++ )
	{
		cout << CH[i].first << " " << CH[i].second << endl;
	}


	return 0;
}